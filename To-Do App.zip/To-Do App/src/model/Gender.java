package model;

public enum Gender {
	yes,
	no
}
