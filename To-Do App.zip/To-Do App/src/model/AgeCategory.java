package model;

public enum AgeCategory {
	Nissan,
	Mazda,
	Land_Rover,
	Lada,
	Honda
}
