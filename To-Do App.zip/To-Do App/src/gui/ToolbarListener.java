package gui;

public interface ToolbarListener {
	public void saveEventOccured();
	public void refreshEventOccured();
}
